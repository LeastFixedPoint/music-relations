package net.miginfocom.examples;

import net.miginfocom.swing.MigLayout;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;

/**
 * @author Mikael Grev, MiG InfoCom AB
 *         Date: Apr 20, 2008
 *         Time: 10:32:58 PM
 */
public class JavaOneShrink
{
	private static JComponent createPanel(String ... args)
	{
		JPanel panel = new JPanel(new MigLayout("nogrid"));

		panel.add(createTextArea(), args[0]);
		panel.add(createTextArea(), args[1]);
		panel.add(createTextArea(), args[2]);
		panel.add(createTextArea(), args[3]);

		JSplitPane gSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, true, panel, new JPanel());
		gSplitPane.setOpaque(true);
		gSplitPane.setBorder(null);

		return gSplitPane;
	}

	private static JComponent createTextArea()
	{
		JTextArea ta = new JTextArea("", 5, 20);
		ta.setBorder(new LineBorder(new Color(200, 200, 200)));
		ta.setMinimumSize(new Dimension(20, 20));
		return ta;
	}

	public static void main(String[] args)
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				JFrame frame = new JFrame("JavaOne Shrink Demo");
				Container cp = frame.getContentPane();
				cp.setLayout(new MigLayout("wrap 1"));

				cp.add(createPanel("", "", "", ""));
				cp.add(createPanel("shp 1", "shp 1", "shp 2", "shp 2"));
				cp.add(createPanel("shrink 25", "shrink 50", "shrink 75", "shrink 100"));
				cp.add(createPanel("shp 1, shrink 50", "shp 1, shrink 100", "shp 2, shrink 50", "shp 2, shrink 100"));

				frame.pack();
				frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
		});
	}

}
